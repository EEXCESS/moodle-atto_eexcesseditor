<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2015081900;
$plugin->component = 'atto_eexcesseditor';
