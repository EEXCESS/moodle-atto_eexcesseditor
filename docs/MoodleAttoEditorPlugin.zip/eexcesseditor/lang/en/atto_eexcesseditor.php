<?php
$string['pluginname'] = 'EEXCESS Editor';
$string['settings'] = 'EEXCESS Editor settings';
$string['citation'] = 'Change citation style';
