copyright: bit media e-solutions GmbH, gerhard.doppler@bitmedia.cc
license: http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or late
Atto EEXCESS Editor plugin for Moodle ======================= Additional plugin for block eexcess (https://moodle.org/plugins/block_eexcess) for inserting citations into a text or image in atto editor.
Instruction manual ======================= https://github.com/EEXCESS/moodle-atto_eexcesseditor/blob/master/README.md